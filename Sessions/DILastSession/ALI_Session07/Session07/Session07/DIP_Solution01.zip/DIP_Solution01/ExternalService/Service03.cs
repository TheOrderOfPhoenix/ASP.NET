﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DIP_Solution01.ExternalService
{
    public class Service03
    {
        #region [ - Ctor - ]
        public Service03()
        {

        }
        #endregion

        #region [ - Method - ]
        public void M3()
        {
            Console.WriteLine("M3 is running ...");
        }
        #endregion
    }
}
