﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DIP_Solution01.ExternalService
{
    public class Service02
    {
        #region [ - Ctor - ]
        public Service02()
        {

        }
        #endregion

        #region [ - Method - ]
        public void M2()
        {
            Console.WriteLine("M2 is running ...");
        }
        #endregion
    }
}
