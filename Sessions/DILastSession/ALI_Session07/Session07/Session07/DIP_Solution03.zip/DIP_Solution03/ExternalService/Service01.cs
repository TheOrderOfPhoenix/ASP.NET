﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DIP_Solution03.ExternalService
{
    public class Service01
    {
        #region [ - Ctor - ]
        public Service01()
        {

        }
        #endregion

        #region [ - Method - ]
        public void M1()
        {
            Console.WriteLine("M1 is running ...");
        }
        #endregion
    }
}
